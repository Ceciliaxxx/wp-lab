<?php
get_header(); 
?>
<div class="categary">
<?php
	get_sidebar(); 
?>
</div>
<div class="container">
<div id="content" role="main">
<ul class="project-list">
<?php
    $term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
  if (have_posts()){
      while (have_posts()) : the_post();?>
          <?php get_template_part('partials/postgrid');?>
          <?php
        endwhile;
    }else{
  ?>
  <li>
		<h3 class="title">Not Found</h3>
    <p>There is no <?php echo $term->name; ?> found</p>
  </li>
  <?php } ?>
  </ul>
</div>
</div>
<?php get_footer(); ?>
