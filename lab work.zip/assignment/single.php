<?php get_header(); ?>
<?php 
  get_template_part('partials/content');
?>
<div class="skill">
  <h3>Skills</h3>
  <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
