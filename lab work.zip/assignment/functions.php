<?php 
  function create_project_taxonomies() {
    $labels = array(
      'name'                       =>  'Project types',
      'singular_name'              =>  'Project type',
      'menu_name'                  =>  'Project types',
      'all_items'                  =>  'All types',
      'new_item_name'              =>  'New Type Name',
      'add_new_item'               =>  'Add New Project Type',
      'edit_item'                  =>  'Edit Project Type',
      'update_item'                =>  'Update Project Type',
      'add_or_remove_items'        =>  'Add or remove Project Types',
      'popular_items'              =>  'Popular Types',
    );
    $args = array(
      'labels'                     => $labels,
      'hierarchical'               => true
    );
    register_taxonomy( 'project_type', array('Projects'), $args );

    $labels = array(
      'name'                       =>  'Project skillz',
      'singular_name'              =>  'Project skill',
      'menu_name'                  =>  'Project skillz',
      'all_items'                  =>  'All Skillz',
      'new_item_name'              =>  'New Skill Name',
      'add_new_item'               =>  'Add New Project Skill',
      'edit_item'                  =>  'Edit Project Skill',
      'update_item'                =>  'Update Project Skill',
      'add_or_remove_items'        =>  'Add or remove Project Skillz',
      'popular_items'              =>  'Popular Skillz',
    );
    $args = array(
      'labels'                     => $labels,
      'hierarchical'               => false
    );
    register_taxonomy( 'project_skill', array('Projects'), $args );
  }
  add_action( 'init', 'create_project_taxonomies' );

  function project_post_type() {
  
      /* Set up the arguments for the post type. */
      $args = array(
        'show_in_nav_menus'   => true, // bool (defaults to 'public')
        'hierarchical'        => false, // bool (defaults to FALSE)        
        'public'              => true, // bool (default is FALSE)
        'menu_icon'           => 'dashicons-portfolio', // string (defaults to use the post icon)
        'supports' => array('thumbnail', 'title', 'editor, author'),
        'taxonomies'            => array( 'project_skill', 'project_type' ),
        'labels' => array(
            'name'               => __( 'Projects',                   'project-textdomain' ),
            'singular_name'      => __( 'Project',                    'project-textdomain' ),
            'menu_name'          => __( 'Projects',                   'project-textdomain' ),
            'name_admin_bar'     => __( 'Projects',                   'project-textdomain' ),
            'add_new'            => __( 'Add New',                    'project-textdomain' ),
            'add_new_item'       => __( 'Add New Project',            'project-textdomain' ),
            'edit_item'          => __( 'Edit Project',               'project-textdomain' ),
            'new_item'           => __( 'New Project',                'project-textdomain' ),
            'view_item'          => __( 'View Project',               'project-textdomain' ),
            'search_items'       => __( 'Search Projects',            'project-textdomain' ),
            'not_found'          => __( 'No projects found',          'project-textdomain' ),
            'not_found_in_trash' => __( 'No projects found in trash', 'project-textdomain' ),
            'all_items'          => __( 'All Projects',               'project-textdomain' ),
        )
      );
  
      /* Register the post type. */
      register_post_type(
          'Projects', // Post type name. Max of 20 characters. Uppercase and spaces not allowed.
          $args      // Arguments for post type.
      );
  }
  
  /* Register custom post types on the 'init' hook. */
  add_action( 'init', 'project_post_type' );

  

  function register_my_menus() {
    register_nav_menus(
      array(
        'header-nav' => __( 'Page menu' )
      )
    );
  }
  add_action( 'init', 'register_my_menus' );
  function add_widgets() {
    $args = array(
      'id'            => 'page-sidebar',
      'name'          => __( 'Page Sidebar', 'portfolio_theme' )
    );
    register_sidebar( $args );

    $args = array(
      'id'            => 'project-sidebar',
      'name'          => __( 'Project Sidebar', 'portfolio_theme' ),
    );
    register_sidebar( $args );
  }
  add_action( 'widgets_init', 'add_widgets' );

  add_theme_support('post-thumbnails');
  add_theme_support('post-formats');

  add_image_size( 'grid_thumbnail', 300, 300, true );
  add_image_size( 'single_large', 660, 400, false );

  add_theme_support( 'post-thumbnails' ); 
// function my_custom_post_movie() {
//   $labels = array(
//     'name'               => _x( 'Movies', 'post type 名称' ),
//     'singular_name'      => _x( 'Movie', 'post type 单个 item 时的名称，因为英文有复数' ),
//     'add_new'            => _x( 'Add Movie', '添加新内容的链接名称' ),
//     'add_new_item'       => __( 'Add a new movie' ),
//     'edit_item'          => __( 'Edit movie' ),
//     'new_item'           => __( 'New Movie' ),
//     'all_items'          => __( 'All Movies' ),
//     'view_item'          => __( 'View Movies' ),
//     'search_items'       => __( 'Search Movies' ),
//     'not_found'          => __( 'No movie found' ),
//     'not_found_in_trash' => __( 'No movie found in trash' ),
//     'parent_item_colon'  => '',
//     'menu_name'          => 'Movies'
//   );
//   $args = array(
//     'labels'        => $labels,
//     'description'   => '我们网站的电影信息',
//     'public'        => true,
//     'menu_position' => 5,
//     'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
//     'has_archive'   => true
//   );
//   register_post_type( 'movie', $args );
// }
// add_action( 'init', 'my_custom_post_movie' );

// function my_taxonomies_movie() {
//   $labels = array(
//     'name'              => _x( 'Movie Categories', 'taxonomy 名称' ),
//     'singular_name'     => _x( 'Movie Categories', 'taxonomy 单数名称' ),
//     'search_items'      => __( 'Search Movie Categories' ),
//     'all_items'         => __( 'All Movie Categories' ),
//     'parent_item'       => __( 'Parent Movie Categories' ),
//     'parent_item_colon' => __( 'Parent Movie Categories Colon' ),
//     'edit_item'         => __( 'Edit Movie Categories' ),
//     'update_item'       => __( 'Update Movie Categories' ),
//     'add_new_item'      => __( 'Add Movie Categories' ),
//     'new_item_name'     => __( 'New Movie Categories' ),
//     'menu_name'         => __( 'Movie Categories' ),
//   );
//   $args = array(
//     'labels' => $labels,
//     'hierarchical' => true,
//   );
//   register_taxonomy( 'movie_category', 'movie', $args );
// }
// add_action( 'init', 'my_taxonomies_movie', 0 );
?>