
          <li class="project">
            <a href="<?php the_permalink(); ?>">
              <div class="thumbnail"><?php the_post_thumbnail(); ?></div>
              <div class="title"><?php the_title();?></div>
          
            </a>
          </li>
