<div id="header" role="banner">
  <?php $heading_tag = ( is_home() || is_front_page() ) ? 'h1' : 'div'; ?>
  <a id="logo" href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>">
    <<?php echo $heading_tag; ?> id="site-title"><?php bloginfo( 'name' ); ?></<?php echo $heading_tag; ?>>
    <div id="site-description"><?php bloginfo( 'description' ); ?></div>
  </a>
  <div id="access" role="navigation">
    <?php /*  hidden div to preload the hover image */ ?>
    <div id="preloader"></div>
    <?php /*  Allow screen readers / text browsers to skip the navigation menu and get right to the good stuff */ ?>
    <div class="skip-link screen-reader-text"><a href="#content" title="<?php esc_attr_e( 'Skip to content', 'twentyten' ); ?>"><?php _e( 'Skip to content', 'twentyten' ); ?></a></div>
    <?php /* Our navigation menu.  If one isn't filled out, wp_nav_menu falls back to wp_page_menu.  The menu assiged to the primary position is the one used.  If none is assigned, the menu with the lowest ID is used.  */ ?>
    <?php wp_nav_menu( array( 'container_class' => 'menu-header', 'theme_location' => 'primary' ) ); ?>
  </div><!-- #access -->

</div><!-- #header -->