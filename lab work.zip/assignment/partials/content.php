
<div class="single-container">
  <div id="content" role="main">
  <?php if (have_posts()) : the_post(); update_post_caches($posts); 
    
  ?>
    
  
    <div class="thumbnail"><?php the_post_thumbnail( 'grid_thumbnail' );  ?></div>
    <h3><?php the_title();  ?></h3>
    <?php
      endif; 
    ?>
    <p><?php the_content();  ?></p>      
  </div>
</div>
