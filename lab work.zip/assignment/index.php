<?php
	get_header(); 
?>
<div class="categary">
<?php
	get_sidebar(); 
?>
</div>
<div class="container">
	<div id="content" role="main">
	<ul class="project-list">
		<?php
			$my_query = new WP_Query(array( 'post_type'=>'Projects'));
				if ($my_query->have_posts()){
						while ( $my_query->have_posts() ){
							$my_query->the_post();
							get_template_part('partials/postgrid');
						}
				}else{
					?>
						<h3 class="title">Not Found</h3>
						<p>There is no project found</p>
				<?php } ?>
		</ul>
	</div>
</div>
<?php get_footer(); ?>
