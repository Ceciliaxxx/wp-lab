<div id="sidebar">
<?php 
	if (is_home() || is_archive()) {
		?>
		<div class="home">
			<a href="<?php echo home_url( '/' ); ?>">All</a>
	</div>
	<ul class="tagcloud">
		<?php
			$terms = get_terms("project_type");
			$count = count($terms);
			if ( $count > 0 ){
				foreach ( $terms as $term ) {
					echo '<li><a href="' . get_term_link( $term ) . '" >' . $term->name . '</a></li>';
				}
			}
		?>
	</ul>
	<?php
		// dynamic_sidebar( 'project-sidebar' ); 
	}
	if (is_page()) {
		// dynamic_sidebar( 'page-sidebar' ); 
		?>
		<h3>Skills</h3>
		<ul class="tagcloud">
		<?php
			$terms = get_terms("project_skill");
			$count = count($terms);
			if ( $count > 0 ){
				foreach ( $terms as $term ) {
					echo '<li><a href="' . get_term_link( $term ) . '" >' . $term->name . '</a></li>';
				}
			}
		?>
	</ul>
	<?php }
	if (is_single()) {
		the_terms( $post->ID, 'project_skill' ,  ' ' );
	}

?>
</div>